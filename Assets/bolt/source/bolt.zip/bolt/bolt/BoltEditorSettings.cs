﻿using UnityEngine;

public enum BoltAutoStarterEditorMode {
  None,
  Server,
  OneClientFromTotal,
  OneClientExtra
}

public enum BoltCompilerTargetMode {
  Server,
  Client,
  AutoStart
}

public class BoltEditorSettings : ScriptableObject {
  static BoltEditorSettings _instance;

  public static BoltEditorSettings instance {
    get {
      if (_instance == null) {
        _instance = (BoltEditorSettings) Resources.Load(typeof(BoltEditorSettings).Name, typeof(BoltEditorSettings));

        if (_instance == null) {
          BoltLog.Error("could not find {0} asset", typeof(BoltEditorSettings));
        }
      }

      return _instance;
    }
  }

  public int debugClientCount = 1;
  public int debugStartPort = 54321;
  public bool useNonProStarter = false;
  public BoltMapAsset debugStartMap = null;
  public BoltConfigAsset debugStartConfig = null;
  public BoltAutoStarterEditorMode debugEditorMode = BoltAutoStarterEditorMode.Server;
  public string debugEditorLanAddress = "";
}
