﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Process = System.Diagnostics.Process;

[InitializeOnLoad]
class BoltUserAssemblyCompiler {

  static string ds {
    get { return Path.DirectorySeparatorChar.ToString(); }
  }

  static string assetDir {
    get { return Application.dataPath; }
  }

  static string tempDir {
    get { return BoltEditorUtils.MakePath(Path.GetDirectoryName(assetDir), "Temp", "bolt"); }
  }

  static string boltAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "bolt.dll"); }
  }

  static string boltUserAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "bolt.user.dll"); }
  }

  static string boltUserAssemblyAsset {
    get { return BoltEditorUtils.MakePath("Assets", "bolt", "assemblies", "bolt.user.dll"); }
  }

  static string udpkitAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "udpkit", "udpkit.dll"); }
  }

  static string udpkitAndroidAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "udpkit", "udpkit.platform.android.dll"); }
  }

  static string udpkitIOSAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "udpkit", "udpkit.platform.ios.dll"); }
  }

  static string udpkitManagedAssemblyPath {
    get { return BoltEditorUtils.MakePath(assetDir, "bolt", "assemblies", "udpkit", "udpkit.platform.managed.dll"); }
  }

  static string eventsFile {
    get { return BoltEditorUtils.MakePath(tempDir, "events.cs"); }
  }

  static string statesFile {
    get { return BoltEditorUtils.MakePath(tempDir, "states.cs"); }
  }

  static string networkFile {
    get { return BoltEditorUtils.MakePath(tempDir, "network.cs"); }
  }

  static string assemblyInfoFile {
    get { return BoltEditorUtils.MakePath(tempDir, "assemblyinfo.cs"); }
  }

  static string prefabsFile {
    get { return BoltEditorUtils.MakePath(tempDir, "prefabs.cs"); }
  }

  static string mecanimFile {
    get { return BoltEditorUtils.MakePath(tempDir, "mecanim.cs"); }
  }

  static string mapsFile {
    get { return BoltEditorUtils.MakePath(tempDir, "maps.cs"); }
  }

  static string commandsFile {
    get { return BoltEditorUtils.MakePath(tempDir, "commands.cs"); }
  }

  static string sourceFileList {
    get {
      return
        "\"" + eventsFile + "\" " +
        "\"" + networkFile + "\" " +
        "\"" + statesFile + "\" " +
        "\"" + prefabsFile + "\" " +
        "\"" + mapsFile + "\" " +
        "\"" + mecanimFile + "\" " +
        "\"" + commandsFile + "\" " +
        "\"" + assemblyInfoFile + "\" ";
    }
  }

  static string assemblyReferencesList {
    get {
      return
        "-reference:\"" + unityengineAssemblyPath + "\" " +
        "-reference:\"" + boltAssemblyPath + "\" " +
        "-reference:\"" + udpkitAssemblyPath + "\" " +
        "-reference:\"" + udpkitAndroidAssemblyPath + "\" " +
        "-reference:\"" + udpkitIOSAssemblyPath + "\" " +
        "-reference:\"" + udpkitManagedAssemblyPath + "\" ";
    }
  }

  static bool isOSX {
    get { return !isWIN; }
  }

  static bool isWIN {
    get {
      return
        Environment.OSVersion.Platform == PlatformID.Win32NT ||
        Environment.OSVersion.Platform == PlatformID.Win32S ||
        Environment.OSVersion.Platform == PlatformID.Win32Windows ||
        Environment.OSVersion.Platform == PlatformID.WinCE;
    }
  }

  static string csharpCompilerPath {
    get {
      if (isOSX) {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "Frameworks/MonoBleedingEdge/lib/mono/2.0/gmcs.exe");
      } else {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "MonoBleedingEdge/lib/mono/2.0/gmcs.exe");
      }
    }
  }

  static string unityengineAssemblyPath {
    get {
      if (isOSX) {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "Frameworks/Managed/UnityEngine.dll");
      } else {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "Managed/UnityEngine.dll");
      }
    }
  }

  static string monoPath {
    get {
      if (isOSX) {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "Frameworks/MonoBleedingEdge/bin/mono");
      } else {
        return BoltEditorUtils.MakePath(EditorApplication.applicationContentsPath, "MonoBleedingEdge/bin/mono.exe");
      }
    }
  }

  static IEnumerable<BoltPrefab> FindPrefabs () {
    int id = 0;

    foreach (var file in Directory.GetFiles(@"Assets", "*.prefab", SearchOption.AllDirectories)) {
      GameObject go = AssetDatabase.LoadAssetAtPath(file, typeof(GameObject)) as GameObject;

      if (go) {
        BoltEntity entity = go.GetComponent<BoltEntity>();

        if (entity) {
          entity.SetField("_prefabId", id);

          EditorUtility.SetDirty(go);
          EditorUtility.SetDirty(entity);

          yield return new BoltPrefab { go = go, id = id, name = go.name.CSharpIdentifier() };
          id += 1;
        }
      }
    }
  }

  public static void Run () {
    try {
      // ensure temp path exists
      Directory.CreateDirectory(tempDir);

      BoltCompilerOperation op = new BoltCompilerOperation();

      // network config
      op.networkFilePath = networkFile;
      op.assemblyInfoFilePath = assemblyInfoFile;

      // events config
      op.eventIdOffset = BoltEvent.USER_START_ID;
      op.eventFilePath = eventsFile;
      op.events = BoltEditorUtils.FindAssets<BoltEventAsset>().ToList();

      // commands config
      op.commands = BoltEditorUtils.FindAssets<BoltCommandAsset>().ToList();
      op.commandsFilePath = commandsFile;

      // maps config
      op.mapsFilePath = mapsFile;
      op.maps = BoltEditorUtils.FindAssets<BoltMapAsset>().ToList();

      // prefabs config
      op.prefabsFilePath = prefabsFile;
      op.prefabs = FindPrefabs().ToList();

      // mecanim config
      op.mecanimFilePath = mecanimFile;
      op.mecanims = BoltEditorUtils.FindAssets<BoltMecanimAsset>().ToList();

      // state config
      op.stateFilePath = statesFile;
      op.states = BoltEditorUtils.FindAssets<BoltStateAsset>().ToList();

      // run code emitter
      BoltCompiler.Run(op);

      // run compiler
      RunCSharpCompiler(op);

    } catch (Exception exn) {
      Debug.LogException(exn);
    }
  }

  static void RunCSharpCompiler (BoltCompilerOperation op) {
#if DEBUG
    const string CMD_ARGS = "\"{0}\" -out:\"{1}\" {2} -platform:anycpu -target:library -debug+ -optimize- ";
#else
    const string CMD_ARGS = "\"{0}\" -out:\"{1}\" {2} -platform:anycpu -target:library -debug- -optimize+ -warn:0 ";
#endif

    string args = CMD_ARGS;

    if (BoltEditorUtils.hasPro == false) {
      args += "-define:UNITY_NOT_PRO ";
    }

    Process p = new Process();
    p.StartInfo.FileName = monoPath;
    p.StartInfo.Arguments = string.Format(args + sourceFileList, csharpCompilerPath, boltUserAssemblyPath, assemblyReferencesList);

    p.EnableRaisingEvents = true;
    p.StartInfo.CreateNoWindow = true;
    p.StartInfo.UseShellExecute = false;
    p.StartInfo.RedirectStandardError = true;
    p.StartInfo.RedirectStandardOutput = true;

    p.ErrorDataReceived += ErrorDataReceived;
    p.OutputDataReceived += OutputDataReceived;

    p.Exited += (s, ea) => {
      BoltMainThreadInvoker.Invoke(() => {
        if (p.ExitCode == 0) {
          AssetDatabase.ImportAsset(boltUserAssemblyAsset, ImportAssetOptions.ForceUpdate);

          ClearCompileFlag(op.events);
          ClearCompileFlag(op.states);
          ClearCompileFlag(op.mecanims);
          ClearCompileFlag(op.commands);

          Debug.Log("BoltCompiler: Success!");

          EditorPrefs.SetInt("BOLT_UNCOMPILED_COUNT", 0);
          EditorPrefs.SetBool(BoltDebugStartWindow.COMPILE_SETTING, false);

          EditorWindow.GetWindow<BoltDebugStartWindow>().Repaint();
        }
      });
    };

    p.Start();
    p.BeginErrorReadLine();
    p.BeginOutputReadLine();
  }

  static void ClearCompileFlag<T> (IEnumerable<T> assets) where T : BoltCompilableAsset {
    foreach (T asset in assets) {
      asset.compile = false;
      EditorUtility.SetDirty(asset);
    }
  }

  static void OutputDataReceived (object sender, System.Diagnostics.DataReceivedEventArgs e) {
    if (e.Data != null) {
      Debug.Log(e.Data);
    }
  }

  static void ErrorDataReceived (object sender, System.Diagnostics.DataReceivedEventArgs e) {
    if (e.Data != null) {
      if (e.Data.Contains(": warning") && !e.Data.Contains(": error")) {
        Debug.LogWarning(e.Data);
      } else {
        Debug.LogError(e.Data);
      }
    }
  }

  static Type FindCommandType () {
    foreach (Type t in typeof(BoltCommand).FindSubtypes()) {
      if (t.HasPublicDefaultConstructor()) {
        return t;
      }
    }

    return null;
  }
}
