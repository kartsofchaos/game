﻿using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UdpKit;
using UnityEngine;

/// <summary>
/// Holds global methods and properties for starting and s
/// topping bolt, instantiating prefabs and other utils
/// </summary>
public static partial class BoltNetwork {
  /// <summary>
  /// The current local simulation frame number
  /// </summary>
  public static int frame {
    get { return BoltCore.frame; }
  }

  /// <summary>
  /// The current server simulation frame number
  /// </summary>
  public static int serverFrame {
    get { return BoltCore.serverFrame; }
  }
  

  /// <summary>
  /// The current server simulation time
  /// </summary>
  public static float serverTime {
    get { return BoltCore.serverTime; }
  }

  /// <summary>
  /// The local time, same as Time.time
  /// </summary>
  public static float time {
    get { return BoltCore.time; }
  }

  /// <summary>
  /// The fixed frame delta, same as Time.fixedDeltaTime
  /// </summary>
  public static float frameDeltaTime {
    get { return BoltCore.frameDeltaTime; }
  }

  /// <summary>
  /// The time the last fixed update begain, same as Time.fixedTime
  /// </summary>
  public static float frameBeginTime {
    get { return BoltCore.frameBeginTime; }
  }

  /// <summary>
  /// All the connections connected to this host
  /// </summary>
  public static IEnumerable<BoltConnection> connections {
    get { return BoltCore.connections; }
  }

  /// <summary>
  /// All clients connected to this host
  /// </summary>
  public static IEnumerable<BoltConnection> clients {
    get { return BoltCore.clients; }
  }

  /// <summary>
  /// The server connection
  /// </summary>
  public static BoltConnection server {
    get { return BoltCore.server; }
  }

  /// <summary>
  /// Maps available for loading
  /// </summary>
  public static BoltMapAsset[] maps {
    get { return BoltCore.maps; }
  }

  /// <summary>
  /// Returns true if this host is a server
  /// </summary>
  public static bool isServer {
    get { return BoltCore.isServer; }
  }

  /// <summary>
  /// Returns true if this host is a client
  /// </summary>
  public static bool isClient {
    get { return BoltCore.isClient; }
  }

  /// <summary>
  /// Returns true if Bolt was compiled in debug mode
  /// </summary>
  public static bool isDebugMode {
    get { return BoltCore.isDebugMode; }
  }

  /// <summary>
  /// The default configuration file
  /// </summary>
  public static BoltConfig defaultConfig {
    get { return BoltCore.defaultConfig.config; }
  }

  /// <summary>
  /// Instantiate a prefab and attach it to bolt
  /// </summary>
  /// <param name="prefab">Prefab to instantiate</param>
  /// <returns>The entity instance of the instantiated prefab</returns>
  public static BoltEntity Instantiate (GameObject prefab) {
    return BoltCore.Instantiate(prefab);
  }
  
  public static Func<int, Transform> resolveTransform {
    get { return BoltCore.resolveTransform; }
    set { BoltCore.resolveTransform = value; }
  }

  public static Func<Transform, int> resolveTransformId {
    get { return BoltCore.resolveTransformId; }
    set { BoltCore.resolveTransformId = value; }
  }
  
  public static BoltEntity Attach (BoltEntity entity) {
    return BoltCore.Attach(entity);
  }

  public static void Detach (BoltEntity entity) {
    BoltCore.Detach(entity);
  }

  /// <summary>
  /// Instantiate a prefab by name and attach it to bolt
  /// </summary>
  /// <param name="prefab">Name of the prefab to instantiate</param>
  /// <returns>The entity instance of the instantiated prefab</returns>
  public static BoltEntity Instantiate (BoltPrefabs prefab) {
    return Instantiate(BoltCore.FindPrefab(prefab.ToString()));
  }

  public static void Destroy (BoltEntity entity) {
    BoltCore.Destroy(entity);
  }
  
  public static void Destroy (GameObject gameobject) {
    BoltCore.Destroy(gameobject);
  }

  /// <summary>
  /// Load a map asset
  /// </summary>
  /// <param name="map">Map to load</param>
  [BoltDocsServerOnly]
  public static void LoadMap (BoltMapAsset map) {
    BoltCore.LoadMap(map);
  }

  /// <summary>
  /// Load a map asset by name
  /// </summary>
  /// <param name="map">Map to load</param>
  [BoltDocsServerOnly]
  public static void LoadMap (BoltMapNames map) {
    BoltCore.LoadMap((int) map);
  }

  /// <summary>
  /// Connect to a server
  /// </summary>
  /// <param name="endpoint">Server end point to connect to</param>
  [BoltDocsClientOnly]
  public static void Connect (UdpEndPoint endpoint) {
    BoltCore.Connect(endpoint);
  }

  /// <summary>
  /// Start a server locally
  /// </summary>
  /// <param name="endpoint">The endpoint to use</param>
  public static void InitializeServer (UdpEndPoint endpoint) {
    InitializeServer(endpoint, defaultConfig);
  }

  /// <summary>
  /// Start a server locally
  /// </summary>
  public static void InitializeServer (UdpEndPoint endpoint, BoltConfig config) {
    BoltCore.InitializeServer(endpoint, new Network(), config);
  }

  /// <summary>
  /// Start a client locally
  /// </summary>
  public static void InitializeClient () {
    InitializeClient(UdpEndPoint.Any);
  }

  /// <summary>
  /// Start a client locally with a specific endpoint
  /// </summary>
  /// <param name="endpoint">The end point to use</param>
  public static void InitializeClient (UdpEndPoint endpoint) {
    InitializeClient(endpoint, defaultConfig);
  }

  /// <summary>
  /// Start a client locally with a specific endpoint and configuration
  /// </summary>
  public static void InitializeClient (UdpEndPoint endpoint, BoltConfig config) {
    BoltCore.InitializeClient(endpoint, new Network(), config);
  }

  /// <summary>
  /// Start a client locally with a specific configuration
  /// </summary>
  public static void InitializeClient (BoltConfig config) {
    InitializeClient(UdpEndPoint.Any, config);
  }

  /// <summary>
  /// Raise a global event
  /// </summary>
  /// <param name="evnt">The event to raise</param>
  public static void Raise (IBoltEvent evnt) {
    BoltCore.Raise(evnt);
  }

  /// <summary>
  /// Shutdown the local host
  /// </summary>
  public static void Shutdown () {
    BoltCore.Shutdown();
  }

  partial class Network : IBoltNetwork {
    Type IBoltNetwork.loadBehaviourType {
      get {
        //MAPLOADER
      }
    }

    UdpPlatform IBoltNetwork.CreateSocketPlatform () {
      switch (Application.platform) {
        case RuntimePlatform.IPhonePlayer:
#if UNITY_NOT_PRO
          return new UdpPlatformIOS();
#endif

        case RuntimePlatform.Android:
#if UNITY_NOT_PRO
          return new UdpPlatformAndroid();
#endif

        case RuntimePlatform.OSXWebPlayer:
        case RuntimePlatform.OSXPlayer:
        case RuntimePlatform.OSXEditor:
        case RuntimePlatform.WindowsEditor:
        case RuntimePlatform.WindowsPlayer:
        case RuntimePlatform.WindowsWebPlayer:
        case RuntimePlatform.LinuxPlayer:
          return new UdpPlatformManaged();
      }

      throw new NotSupportedException(string.Format("platform '{0}' not supported by udpkit", Application.platform));
    }

    void IBoltNetwork.Setup () {
      //EVENTS
      //STATE
      //COMMANDS
    }

    void IBoltNetwork.Reset () {
      //RESET
    }
  }
}
