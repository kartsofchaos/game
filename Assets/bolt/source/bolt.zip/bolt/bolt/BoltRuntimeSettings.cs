﻿using System;
using System.Linq;
using UnityEngine;

public class BoltRuntimeSettings : ScriptableObject {
  static BoltRuntimeSettings _instance;

  public static BoltRuntimeSettings instance {
    get {
      if (_instance == null) {
        _instance = (BoltRuntimeSettings) Resources.Load(typeof(BoltRuntimeSettings).Name, typeof(BoltRuntimeSettings));

        if (_instance == null) {
          BoltLog.Error("could not find {0} asset", typeof(BoltRuntimeSettings));
        }
      }

      return _instance;
    }
  }

  [SerializeField]
  internal GameObject[] _prefabs = new GameObject[0];

  [SerializeField]
  internal BoltMapAsset[] _mapAssets = new BoltMapAsset[0];

  internal static GameObject[] prefabs {
    get {
      if (!instance)
        return new GameObject[0];

      return instance._prefabs;
    }
  }

  internal static BoltMapAsset[] mapAssets {
    get {
      if (!instance)
        return new BoltMapAsset[0];

      return instance._mapAssets;
    }
  }

  internal static BoltMapAsset FindMapAsset (int id) {
    try {
      for (int i = 0; i < mapAssets.Length; ++i) {
        if (mapAssets[i]._id == id) {
          return mapAssets[i];
        }
      }
    } catch (Exception exn) {
      BoltLog.Exception(exn);
    }

    return null;
  }

  internal static GameObject FindPrefab (string name) {
    return prefabs.FirstOrDefault(x => x.name == name);
  }

  internal static bool ContainsPrefab (BoltEntity entity) {
    if (prefabs == null)
      return false;

    if (!entity)
      return false;

    if (entity.boltPrefabId >= BoltRuntimeSettings.prefabs.Length)
      return false;

    if (entity.boltPrefabId < 0)
      return false;

    return BoltRuntimeSettings.prefabs[entity.boltPrefabId] == entity.gameObject;
  }
}
