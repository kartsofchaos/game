﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(BoltEditorSettings))]
public class BoltEditorSettingsEditor : Editor {
  public override void OnInspectorGUI () {
  }
}
