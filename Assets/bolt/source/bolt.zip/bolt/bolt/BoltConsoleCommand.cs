﻿//using System;

//[AttributeUsage(AttributeTargets.Method, Inherited = false, AllowMultiple = true)]
//public sealed class BoltConsoleCommandAttribute : Attribute {
//  public string command { get; private set; }

//  public BoltConsoleCommandAttribute (string cmd) {
//    command = cmd;
//  }
//}
