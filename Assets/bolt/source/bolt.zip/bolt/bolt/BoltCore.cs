﻿using System;
using System.Collections.Generic;
using System.Linq;
using UdpKit;
using UnityEngine;
using Rand = System.Random;
using Stopwatch = System.Diagnostics.Stopwatch;

enum BoltNetworkModes {
  None = 0,
  Server = 1,
  Client = 2
}

internal static class BoltCore {
  public const int MAX_CONNECTIONS = 128;
  public const int PACKET_SIZE = 1024;

  static UdpSocket _udpSocket;

  static internal BoltMapLoadOp _loadedMap;
  static internal BoltMapLoadOp _loadedMapTarget;

  static internal int _frame = 0;
  static internal BoltNetworkModes _mode = BoltNetworkModes.None;
  static internal IBoltNetwork _autogen = null;
  static internal BoltConfig _config = null;
  static internal BoltConfig _configCopy = null;
  static internal BoltDoubleList<BoltConnection> _connections = new BoltDoubleList<BoltConnection>();
  static internal BoltDoubleList<BoltEntityProxy> _proxies = new BoltDoubleList<BoltEntityProxy>();
  static internal BoltDoubleList<BoltEntity> _entities = new BoltDoubleList<BoltEntity>();
  static internal BoltEventDispatcher _eventDispatcher = new BoltEventDispatcher();

  public static bool isDebugMode {
#if DEBUG
    get { return true; }
#else
    get { return false; }
#endif
  }

  public static GameObject userObject {
    get;
    private set;
  }

  public static Func<int, Transform> resolveTransform = BoltOrigin.ResolveTransform;
  public static Func<Transform, int> resolveTransformId = BoltOrigin.ResolveTransformId;

  public static UdpConfig udpConfig {
    get { return _udpSocket.ConfigCopy; }
  }

  public static BoltMapAsset[] maps {
    get { return BoltRuntimeSettings.mapAssets; }
  }

  public static GameObject[] prefabs {
    get { return BoltRuntimeSettings.prefabs; }
  }

  public static BoltMapAsset loadedMap {
    get {
      if (_loadedMap.isValid) {
        return BoltRuntimeSettings.FindMapAsset(_loadedMap.map);
      }

      return null;
    }
  }

  public static BoltConfigAsset defaultConfig {
    get { return Resources.Load("BoltDefaultConfig", typeof(BoltConfigAsset)) as BoltConfigAsset; }
  }

  public static BoltConfig networkConfig {
    get { return _configCopy; }
  }

  public static IEnumerable<BoltEntity> entities {
    get { return _entities; }
  }

  public static IEnumerable<BoltConnection> connections {
    get { return _connections; }
  }

  public static IEnumerable<BoltConnection> clients {
    get { return connections.Where(c => c.udpConnection.IsServer); }
  }

  public static BoltConnection server {
    get { return connections.FirstOrDefault(c => c.udpConnection.IsClient); }
  }

  public static int frame {
    get { return _frame; }
  }

  public static int framesPerSecond {
    get { return _config.framesPerSecond; }
  }

  public static int serverFrame {
    get { return _mode == BoltNetworkModes.None ? 0 : (isServer ? _frame : server.remoteFrame); }
  }

  public static float serverTime {
    get { return ((float) serverFrame) / ((float) framesPerSecond); }
  }

  public static float time {
    get { return Time.time; }
  }

  public static float frameBeginTime {
    get { return Time.fixedTime; }
  }

  public static float frameDeltaTime {
    get { return Time.fixedDeltaTime; }
  }

  public static bool isClient {
    get { return hasSocket && _mode == BoltNetworkModes.Client; }
  }

  public static bool isServer {
    get { return hasSocket && _mode == BoltNetworkModes.Server; }
  }

  internal static int localSendRate {
    get {
      switch (_mode) {
        case BoltNetworkModes.Server: return _config.serverSendRate;
        case BoltNetworkModes.Client: return _config.clientSendRate;
        default: return -1;
      }
    }
  }

  internal static int localSendRateBits {
    get { return BoltMath.Hibit((uint) localSendRate); }
  }

  internal static int remoteSendRate {
    get {
      switch (_mode) {
        case BoltNetworkModes.Server: return _config.clientSendRate;
        case BoltNetworkModes.Client: return _config.serverSendRate;
        default: return -1;
      }
    }
  }

  internal static int remoteSendRateBits {
    get { return BoltMath.Hibit((uint) remoteSendRate); }
  }

  internal static int localInterpolationDelay {
    get {
      switch (_mode) {
        case BoltNetworkModes.Server: return _config.serverDejitterDelay;
        case BoltNetworkModes.Client: return _config.clientDejitterDelay;
        default: return -1;
      }
    }
  }

  internal static int localInterpolationDelayMin {
    get {
      switch (_mode) {
        case BoltNetworkModes.Server: return _config.serverDejitterDelayMin;
        case BoltNetworkModes.Client: return _config.clientDejitterDelayMin;
        default: return -1;
      }
    }
  }

  internal static int localInterpolationDelayMax {
    get {
      switch (_mode) {
        case BoltNetworkModes.Server: return _config.serverDejitterDelayMax;
        case BoltNetworkModes.Client: return _config.clientDejitterDelayMax;
        default: return -1;
      }
    }
  }

  internal static bool hasSocket {
    get { return _udpSocket != null; }
  }

  public static void InitializeServer (UdpEndPoint endpoint, IBoltNetwork autogen, BoltConfig config) {
    Initialize(BoltNetworkModes.Server, endpoint, autogen, config);
  }

  public static void InitializeClient (UdpEndPoint endpoint, IBoltNetwork autogen, BoltConfig config) {
    Initialize(BoltNetworkModes.Client, endpoint, autogen, config);
  }

  public static BoltEntity Instantiate (GameObject prefab) {
    return InstantiateAttach(prefab, null, Bits.zero);
  }

  public static void Destroy (BoltEntity entity) {
    entity.Detach();
    GameObject.Destroy(entity.gameObject);
  }

  public static void Destroy (GameObject go) {
    BoltEntity entity = go.GetComponent<BoltEntity>();

    if (entity) {
      Destroy(entity);
    } else {
      BoltLog.Error("Can only destroy gameobjects with an BoltEntity component through BoltNetwork.Destroy");
    }
  }

  public static BoltEntity Attach (BoltEntity entity) {
    entity.Attach(null, Bits.zero);
    return entity;
  }

  public static void Detach (BoltEntity entity) {
    entity.Detach();
  }

  internal static BoltEntity InstantiateAttach (GameObject prefab, BoltConnection source, Bits flags) {
    prefab.GetComponent<BoltEntity>()._sceneObject = false;

    GameObject go = (GameObject) GameObject.Instantiate(prefab);
    BoltEntity be = go.GetComponent<BoltEntity>();

    be.Attach(source, flags);
    return be;
  }

  public static void DontDestroyOnMapLoad (BoltEntity entity) {
    entity._flags |= BoltEntity.FLAG_PERSIST_ON_MAP_LOAD;
  }

  public static GameObject FindPrefab (string name) {
    return BoltRuntimeSettings.FindPrefab(name);
  }

  public static void LoadMap (int id) {
    LoadMap(BoltRuntimeSettings.FindMapAsset(id));
  }

  public static void LoadMap (BoltMapAsset map) {
    // only the server can load a map
    if (isServer == false) {
      BoltLog.Error("only server can initiate a map load");
      return;
    }

    LoadMapInternal(new BoltMapLoadOp(map, _loadedMapTarget));
  }

  public static void Shutdown () {
    if (_udpSocket != null) {
      try {
        BoltCallbacksBase.ShutdownBeginInvoke();

        if (userObject) {
          GameObject.Destroy(userObject);
          userObject = null;
        }

        foreach (BoltEntity entity in entities.ToArray()) {
          Destroy(entity);
        }

        _proxies.Clear();
        _entities.Clear();
        _connections.Clear();
        _eventDispatcher._targets.Clear();

        BoltUtils.DestroySingleton(_autogen.loadBehaviourType);

        _autogen.Reset();
        _autogen = null;

        _udpSocket.Close();
        _udpSocket = null;

        _mode = BoltNetworkModes.None;

        BoltUtils.DestroySingleton(typeof(BoltPoll));
        BoltUtils.DestroySingleton(typeof(BoltSend));
        BoltUtils.DestroySingleton(typeof(BoltEventClientReceiver));
        BoltUtils.DestroySingleton(typeof(BoltEventServerReceiver));

        BoltFactory.UnregisterAll();

      } finally {
        BoltCallbacksBase.ShutdownDoneInvoke();
      }
    }
  }

  public static void Connect (UdpEndPoint endpoint) {
    if (server != null) {
      BoltLog.Error("You must disconnect from the current server first");
      return;
    }

    _udpSocket.Connect(endpoint);
  }

  public static void Raise (IBoltEvent evnt) {
    BoltEvent.Invoke((BoltEvent) evnt);
  }

  static void StepRemoteFrames () {
    BoltConnection cn;
    BoltIterator<BoltConnection> cnIter;

    if (hasSocket) {
      cn = null;
      cnIter = _connections.GetIterator();

      while (cnIter.Next(out cn)) {
        cn.AdjustRemoteFrame();
      }

      bool retry;

      do {
        retry = false;

        cn = null;
        cnIter = _connections.GetIterator();

        while (cnIter.Next(out cn)) {
          if (cn.StepRemoteFrame()) {
            retry = true;
          }
        }
      } while (retry);
    }
  }

  static void PollNetwork () {
    UdpEvent ev;

    while (hasSocket && _udpSocket.Poll(out ev)) {
      switch (ev.EventType) {
        case UdpEventType.Connected:
          HandleConnected(ev.Connection);
          break;

        case UdpEventType.Disconnected:
          HandleDisconnected(ev.Connection.GetBoltConnection());
          break;

        case UdpEventType.ConnectRequest:
          BoltCallbacksBase.ConnectRequestInvoke(ev.EndPoint);
          break;

        case UdpEventType.ConnectFailed:
          BoltCallbacksBase.ConnectFailedInvoke(ev.EndPoint);
          break;

        case UdpEventType.ConnectRefused:
          BoltCallbacksBase.ConnectRefusedInvoke(ev.EndPoint);
          break;

        case UdpEventType.ObjectSent:
          ev.Connection.GetBoltConnection().PacketSent((BoltPacket) ev.Object);
          break;

        case UdpEventType.ObjectReceived:
          using ((BoltPacket) ev.Object) {
            ev.Connection.GetBoltConnection().PacketReceived((BoltPacket) ev.Object);
          }
          break;

        case UdpEventType.ObjectDelivered:
          using ((BoltPacket) ev.Object) {
            ev.Connection.GetBoltConnection().PacketDelivered((BoltPacket) ev.Object);
          }
          break;

        case UdpEventType.ObjectLost:
        case UdpEventType.ObjectRejected:
        case UdpEventType.ObjectSendFailed:
          using ((BoltPacket) ev.Object) {
            ev.Connection.GetBoltConnection().PacketLost((BoltPacket) ev.Object);
          }
          break;
      }
    }
  }

  internal static void LoadMapInternal (BoltMapLoadOp loadOp) {
    foreach (BoltEntity entity in entities) {
      // destroy entities which we are in control of and which are not labelled as proxies
      if (entity._flags & BoltEntity.FLAG_IS_PROXY) { continue; }
      if (entity._flags & BoltEntity.FLAG_PERSIST_ON_MAP_LOAD) { continue; }

      // pop!
      Destroy(entity);
    }

    // debug and stuff
    //BoltLog.Debug("loading map {0}", map);

    // the current "target" (where we cant to get in the end)
    _loadedMapTarget = loadOp;

    // load map for ourselves
    BoltMapLoader.LoadMap(_loadedMapTarget);
  }

  internal static void Send () {
    if (hasSocket) {
      BoltPhysics.SnapshotWorld();

      if (_frame % framesPerSecond == 0) {
        var it = _connections.GetIterator();

        while (it.Next()) {
          it.val.SwitchPerfCounters();
        }
      }

      if ((_frame % localSendRate) == 0) {
        // update the scope for all connections/entities
        BoltCore.UpdateScope();

        // copy all bitmasks from entities to proxies
        BoltEntityProxy proxy = null;
        var proxyIter = _proxies.GetIterator();

        while (proxyIter.Next(out proxy)) {
          if (proxy.entity) {
            if (proxy.entity.IsControlledBy(proxy.connection)) {
              proxy.mask |= (proxy.entity._mask & proxy.entity.boltSerializer.controllerMask);
            } else {
              proxy.mask |= (proxy.entity._mask & proxy.entity.boltSerializer.proxyMask);
            }
          }
        }

        // clear all masks on entities
        BoltEntity entity = null;
        var entityIter = _entities.GetIterator();

        while (entityIter.Next(out entity)) {
          entity._mask = Bits.zero;
        }

        // send out updates to all connections
        BoltConnection cn;
        var cnIter = _connections.GetIterator();

        while (cnIter.Next(out cn)) {
          cn.Send();
        }
      }
    }
  }

  internal static void FixedUpdate () {
    if (hasSocket) {
      _frame += 1;

      // first thing we do is to poll the network
      BoltCore.PollNetwork();

      // step remote rpcs and entities which depends on remote esimate frame numbers
      BoltCore.StepRemoteFrames();

      // step entities which we in some way are controlling locally
      BoltEntity entity = null;
      var entityIter = _entities.GetIterator();

      while (entityIter.Next(out entity)) {
        if (entity.boltIsOwner) {
          entity.SimulateStep();
        } else {
          if (entity.boltIsControlling) {
            entity.SimulateStep();
          }
        }
      }
    }
  }

  static void HandleConnected (UdpConnection udp) {
    BoltConnection cn = new BoltConnection(udp);

    // put on connection list
    _connections.AddLast(cn);

    // load map on clients which connect
    if (isServer) {
      if (_loadedMapTarget.isValid) {
        cn.LoadMapOnClient(_loadedMapTarget);
      } else {
        BoltLog.Warning("{0} connected without server having a map loading or loaded", cn);
      }
    }

    // generic connected callback
    BoltCallbacksBase.ConnectedInvoke(cn);

    // invoke callback depending on connection type
    if (cn.udpConnection.IsServer) { BoltCallbacksBase.ClientConnectedInvoke(cn); } else { BoltCallbacksBase.ConnectedToServerInvoke(cn); }
  }

  static void HandleDisconnected (BoltConnection cn) {
    // invoke callback depending on connection type
    if (cn.udpConnection.IsServer) { BoltCallbacksBase.ClientDisconnectedInvoke(cn); } else { BoltCallbacksBase.DisconnectedFromServerInvoke(cn); }

    // generic disconnected callback
    BoltCallbacksBase.DisconnectedInvoke(cn);

    // cleanup                                                      
    try {
      cn.DisconnectedInternal();
    } catch (Exception exn) {
      BoltLog.Error(exn);
    }

    // remove from connection list
    _connections.Remove(cn);

    // if this is the client, we should shutdown all of botl when we get disconnected
    if (cn.udpConnection.IsClient) {
      Shutdown();
    }
  }

  static void UpdateScope () {
    BoltConnection cn;
    var cnIter = _connections.GetIterator();

    while (cnIter.Next(out cn)) {
      // if this connection isn't allowed to proxy objects, skip it
      if (cn._flags & BoltConnection.FLAG_LOADING_MAP) { continue; }

      BoltEntity en = null;
      var enIter = _entities.GetIterator();

      while (enIter.Next(out en)) {
        // if proxying is disabled for this object, skip it
        if (en._flags & BoltEntity.FLAG_DISABLE_PROXYING) { continue; }

        // if this object originates from this connection, skip it
        if (ReferenceEquals(en.boltSource, en)) { continue; }

        // a controlling connection is always considered in scope
        bool scope = en.boltSerializer.InScope(cn) || ReferenceEquals(en._remoteController, cn);
        bool exists = cn._entityChannel.ExistsOnRemote(en);

        // if we DO exists on remote but ARE NOT in scope
        // anymore, we should mark the proxy for deletion
        if (exists && !scope) {
          cn._entityChannel.DestroyOnRemote(en, BoltEntityDestroyMode.OutOfScope);
        }

        // if we DO NOT exist on remote but ARE in scope
        // we should create a new proxy on this connection
        if (!exists && scope) {
          cn._entityChannel.CreateOnRemote(en);
        }
      }
    }
  }

  static void SpawnUserToken (GameObject go) {
    if (go) {
      userObject = (GameObject) GameObject.Instantiate(go);
    }
  }

  static void Initialize (BoltNetworkModes mode, UdpEndPoint endpoint, IBoltNetwork autogen, BoltConfig config) {
    Time.fixedDeltaTime = 1f / (float) config.framesPerSecond;

    // :)
    BoltLog.Debug("bolt starting at {0} fps / {1} frametime", config.framesPerSecond, Time.fixedDeltaTime);

    // set udpkits log writer
    UdpLog.SetWriter(UdpLogWriter);

    // close any existing socket
    Shutdown();

    switch (mode) {
      case BoltNetworkModes.Client: SpawnUserToken(config.clientObject); break;
      case BoltNetworkModes.Server: SpawnUserToken(config.serverObject); break;
    }

    // callback
    BoltCallbacksBase.StartBeginInvoke();

    // setup config
    _config = config;
    _configCopy = _config.Clone();

    // unregister all handlers
    BoltFactory.UnregisterAll();

    // register our handlers
    BoltFactory.Register(new LoadMapFactory());
    BoltFactory.Register(new LoadMapDoneFactory());

    // setup autogen and mode
    _mode = mode;
    _autogen = autogen;
    _autogen.Setup();

    // make sure our singletons exist
    BoltUtils.CreateSingleton(_autogen.loadBehaviourType);
    BoltUtils.CreateSingleton(typeof(BoltPoll));
    BoltUtils.CreateSingleton(typeof(BoltSend));

    // create singleton event receivers
    if (mode == BoltNetworkModes.Server) {
      BoltUtils.CreateSingleton(typeof(BoltEventServerReceiver));
    } else {
      BoltUtils.CreateSingleton(typeof(BoltEventClientReceiver));
    }

    // setup configuration
    UdpConfig udpConfig = new UdpConfig {
      ConnectionLimit = mode == BoltNetworkModes.Server ? config.serverConnectionLimit : 1,
#if DEBUG
      ConnectionTimeout = 600000,
      ConnectRequestAttempts = 100,
      ConnectRequestTimeout = 1000,
#else
      ConnectionTimeout = 5000,
      ConnectRequestAttempts = 10,
      ConnectRequestTimeout = 1000,
#endif
      AllowImplicitAccept = mode == BoltNetworkModes.Client,
      AllowIncommingConnections = mode == BoltNetworkModes.Server,
      AutoAcceptIncommingConnections = mode == BoltNetworkModes.Server,
      PingTimeout = (uint) (localSendRate * 1.5f * frameDeltaTime * 1000f),
      PacketSize = PACKET_SIZE,
      SimulatedLoss = Mathf.Clamp01(config.simulatedLoss),
      SimulatedPingMin = Mathf.Max(0, (config.simulatedPingMean >> 1) - (config.simulatedPingJitter >> 1)),
      SimulatedPingMax = Mathf.Max(0, (config.simulatedPingMean >> 1) + (config.simulatedPingJitter >> 1)),
      UseAvailableEventEvent = false,
    };

#if DEBUG
    switch (config.simulatedRandomFunction) {
      case BoltRandomFunction.PerlinNoise:
        float x = UnityEngine.Random.value;
        Stopwatch sw = Stopwatch.StartNew();
        udpConfig.NoiseFunction = () => Mathf.PerlinNoise(x, (float) sw.Elapsed.TotalSeconds);
        break;

      case BoltRandomFunction.SystemRandom:
        Rand rnd = new Rand();
        udpConfig.NoiseFunction = () => (float) rnd.NextDouble();
        break;
    }
#endif

    // create and start socket
    _udpSocket = UdpSocket.Create(_autogen.CreateSocketPlatform(), () => new BoltSerializer(), udpConfig);
    _udpSocket.Start(endpoint);

    // call out to user
    BoltCallbacksBase.StartDoneInvoke();
  }

  static void UdpLogWriter (uint level, string message) {
    switch (level) {
#if DEBUG
      case UdpLog.DEBUG:
      case UdpLog.TRACE:
        BoltLog.Debug(message);
        break;
#endif

      case UdpLog.USER:
      case UdpLog.INFO:
        BoltLog.Info(message);
        break;

      case UdpLog.WARN:
        BoltLog.Warning(message);
        break;

      case UdpLog.ERROR:
        BoltLog.Error(message);
        break;
    }
  }
}
