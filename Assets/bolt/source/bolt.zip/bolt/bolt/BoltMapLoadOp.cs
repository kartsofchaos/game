﻿using System;
using UnityEngine;

/// <summary>
/// Describes a map loading operation
/// </summary>
public struct BoltMapLoadOp : IEquatable<BoltMapLoadOp> {
  internal int map;
  internal int token;

  /// <summary>
  /// The map asset this operation wants to load
  /// </summary>
  public BoltMapAsset mapAsset {
    get { return BoltRuntimeSettings.FindMapAsset(map); }
  }

  /// <summary>
  /// If this is a valid load operation
  /// </summary>
  public bool isValid {
    get { return map > 0 && token > 0; }
  }

  internal BoltMapLoadOp (BoltMapAsset map, BoltMapLoadOp previous) {
    this.map = map._id;
    this.token = previous.token + 1;
  }

  public bool Equals (BoltMapLoadOp other) {
    return this.map == other.map && this.token == other.token;
  }
}